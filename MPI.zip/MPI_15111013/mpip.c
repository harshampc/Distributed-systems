#include <stdio.h>
#include <mpi.h>
#include <math.h>
   
#define stag 2001
#define rtag 2002
//mpicc -o mpip mpip.c -lm
//mpirun -np 5 ./mpip


   
   	int checkprime(int a)
	{
	   int c;
	   if(a==1) return 0;
	   for ( c = 2 ; c <= a - 1 ; c++ )
	   { 
	      if ( a%c == 0 )
		 return 0;
	   }
	   if ( c == a )
	      return 1;
	}

   main(int argc, char **argv) 
   {
       int mf=0,sf=0,mp1,mp2,sp1,sp2;//mf,sf are flags, mp1,mp2,sp1,sp2 are primes of master and slaves respectively
      MPI_Status status;
      int inp, slinp, sqinp, my_id, rootpr, ierr, i, N, i_id, slel, slsl, lim_per_p, sender, sl, el;//N is number of processes
	
	
      /*Replicating this process to create parallel processes. From this point on, every process executes a seperate copy of this program */

      ierr = MPI_Init(&argc, &argv);
      rootpr = 0;
      
      /* finding out process ID, and how many processes were started. */
      
      ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
      ierr = MPI_Comm_size(MPI_COMM_WORLD, &N);

      if(my_id == rootpr) {
         
         /* Root process, taking input */

         printf("please enter the number to be cracked: ");
         scanf("%i", &inp);
	
	 sqinp=(int)sqrt(inp);

         lim_per_p =  sqinp/ N;


         /* distribute a portion of computation to each child process */
   
         for(i_id = 1; i_id < N; i_id++) {
            sl= i_id*lim_per_p + 1;
            el  = (i_id + 1)*lim_per_p;

            if((sqinp - el) < lim_per_p)
               el= sqinp - 1;

            ierr = MPI_Send( &sl, 1 , MPI_INT,i_id, stag, MPI_COMM_WORLD);
	    ierr = MPI_Send( &el, 1 , MPI_INT,i_id, stag, MPI_COMM_WORLD);
	    ierr = MPI_Send( &inp, 1 , MPI_INT,i_id, stag, MPI_COMM_WORLD);

         }

         /* computation assigned to root process*/
        
         
         for(i = 2; i < lim_per_p + 1; i++) {
            if(checkprime(i))
		{  mp1=i;
		   mp2=inp/i;
		 if(checkprime(mp2))
		 {mf=1;break;}
		}
	
         } 
	
	if(mp1<=1||mp2<=1||mp1*mp2!=inp)mf=0;
	printf("Computation in root process:\n");
	printf("Following are limits for root process: 2 and %d \n",lim_per_p);
	if(mf)
         printf("Following are pair of prime numbers which crack key: %d and %d \n\n", mp1,mp2);
	else
	 printf("Root process could not crack.\n\n");

         /* collect the partial computations from the slave processes, 
          * print them, and combine with computation of master, and print it */

         for(i_id = 1; i_id < N; i_id++) {
            
            ierr = MPI_Recv( &sp1, 1, MPI_INT, MPI_ANY_SOURCE,rtag, MPI_COMM_WORLD, &status);
	    ierr = MPI_Recv( &sp2, 1, MPI_INT, MPI_ANY_SOURCE,rtag, MPI_COMM_WORLD, &status);
	    ierr = MPI_Recv( &sf, 1, MPI_INT, MPI_ANY_SOURCE,rtag, MPI_COMM_WORLD, &status);
  
            sender = status.MPI_SOURCE;

	    sl= i_id*lim_per_p + 1;
            el  = (i_id + 1)*lim_per_p;

            if((sqinp - el) < lim_per_p)
               el= sqinp - 1;
		
	    
	    printf("Computation returned from process %i:\n",sender);
	    printf("Following are limits for this process: %d and %d \n",sl,el);
		if(sf)
		{ if(sp1*sp2==inp)printf("Following are pair of prime numbers which crack key: %d and %d \n\n", sp1,sp2);
		else
		 printf("This process could not crack.\n\n");
		}
		else
		 printf("This process could not crack.\n\n");

    
         }

      }

      else {

         /*  slave process,receiving start limit and end limit */

         ierr = MPI_Recv( &slsl, 1, MPI_INT,rootpr, stag, MPI_COMM_WORLD, &status);
	 ierr = MPI_Recv( &slel, 1, MPI_INT,rootpr, stag, MPI_COMM_WORLD, &status);
	 ierr = MPI_Recv( &slinp, 1, MPI_INT,rootpr, stag, MPI_COMM_WORLD, &status);

         /* Calculate the sum of my portion of the array */

	sf=0;
	for(i = slsl; i < slel + 1; i++) {
            if(checkprime(i))
		{  sp1=i;
		   sp2=slinp/i;
		 if(checkprime(sp2))
		 {sf=1;break;}
		}
	
         } 
      
	

         /* returning partial computation to root process */

         ierr = MPI_Send( &sp1,1, MPI_INT, rootpr,rtag, MPI_COMM_WORLD);
	 ierr = MPI_Send( &sp2,1, MPI_INT, rootpr,rtag, MPI_COMM_WORLD);
	 ierr = MPI_Send( &sf,1, MPI_INT, rootpr,rtag, MPI_COMM_WORLD);
      }
      ierr = MPI_Finalize();
   }
