﻿using System.Windows.Forms;
using System;
using System.Collections.Generic;

namespace MutualExclusion
{
    public class Car
    {
        public PictureBox car;
        public Queue<QueueItem> RQ;
        public bool bridgecrossed;
        public long timestamp;
        public bool lockgained;
        public int timeincrement;
        public Direction DirectionOnBridge;
        public Car(PictureBox car)
        {
            this.car = car;
            RQ = new Queue<QueueItem>();
            bridgecrossed = false;
            lockgained = true;
            timeincrement = new Random().Next(1,5);
        }

        public void getMessage(Message message)
        {
            switch(message.type)
            {
                case MessageType.Request:
                    timestamp = message.timestamp > timestamp ? message.timestamp + 1 : timestamp;
                    RQ.Enqueue(new QueueItem(message.timestamp, message.senderid));
                    sendMessage(message.senderid, new Message(MessageType.Reply, timestamp, this));
                    break;
                case MessageType.Reply:
                   // if (message.timestamp <= timestamp) lockgained = false;
                    break;
                case MessageType.Release:
                    Queue<QueueItem> temp = new Queue<QueueItem>();
                    foreach(QueueItem item in RQ)
                    {
                        if (!item.car.Equals(message.senderid))
                            temp.Enqueue(item);
                    }
                    RQ = temp;
                    if (RQ.Count!=0&&RQ.Peek().car.Equals(this))
                        lockgained = true;
                    break;

            }
        }
        public void sendMessage(Car destination,Message message)
        {
            destination.getMessage(message);
        }

        public void getBridge(List<Car> RequestSet)
        {
            lockgained = true;
            foreach (Car competitor in RequestSet)
            {
                sendMessage(competitor, new Message(MessageType.Request, timestamp, this));
            }
            RQ.Enqueue(new QueueItem(timestamp, this));

        }

        public void release(List<Car> RequestSet)
        {
            lockgained = false;
            DirectionOnBridge = Direction.Default;
            foreach (Car competitor in RequestSet)
            {
                sendMessage(competitor, new Message(MessageType.Release, timestamp, this));
            }
        }
        
    }
}