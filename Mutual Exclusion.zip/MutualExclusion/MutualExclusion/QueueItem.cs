﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MutualExclusion
{
    public class QueueItem
    {
        public long timestamp;
        public Car car;
        public QueueItem(long timestamp , Car car)
        {
            this.timestamp = timestamp;
            this.car = car;
        }
    }
}