﻿namespace MutualExclusion
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ro = new System.Windows.Forms.PictureBox();
            this.bridge = new System.Windows.Forms.PictureBox();
            this.b1 = new System.Windows.Forms.PictureBox();
            this.b2 = new System.Windows.Forms.PictureBox();
            this.r2 = new System.Windows.Forms.PictureBox();
            this.r1 = new System.Windows.Forms.PictureBox();
            this.bo = new System.Windows.Forms.PictureBox();
            this.bi = new System.Windows.Forms.PictureBox();
            this.ri = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.pause = new System.Windows.Forms.Button();
            this.resume = new System.Windows.Forms.Button();
            this.speed = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.start = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bridge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.r1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.speed)).BeginInit();
            this.SuspendLayout();
            // 
            // ro
            // 
            this.ro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ro.Location = new System.Drawing.Point(550, 150);
            this.ro.Name = "ro";
            this.ro.Size = new System.Drawing.Size(300, 200);
            this.ro.TabIndex = 0;
            this.ro.TabStop = false;
            // 
            // bridge
            // 
            this.bridge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.bridge.Location = new System.Drawing.Point(350, 245);
            this.bridge.Name = "bridge";
            this.bridge.Size = new System.Drawing.Size(200, 10);
            this.bridge.TabIndex = 2;
            this.bridge.TabStop = false;
            // 
            // b1
            // 
            this.b1.BackColor = System.Drawing.Color.DarkBlue;
            this.b1.Location = new System.Drawing.Point(340, 150);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(10, 10);
            this.b1.TabIndex = 3;
            this.b1.TabStop = false;
            this.b1.Tag = "Blue Car 1";
            this.toolTip1.SetToolTip(this.b1, "You can change location of car to somewhere else on path by dragging and dropping" +
        " at desired location. \r\nPlease drop exactly on path!!");
            this.b1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouseDown);
            this.b1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouseMove);
            this.b1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mouseUp);
            // 
            // b2
            // 
            this.b2.BackColor = System.Drawing.Color.Blue;
            this.b2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.b2.Image = ((System.Drawing.Image)(resources.GetObject("b2.Image")));
            this.b2.Location = new System.Drawing.Point(50, 340);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(10, 10);
            this.b2.TabIndex = 4;
            this.b2.TabStop = false;
            this.b2.Tag = "Blue Car 2";
            this.toolTip1.SetToolTip(this.b2, "You can change location of car to somewhere else on path by dragging and dropping" +
        " at desired location. \r\nPlease drop exactly on path!!");
            this.b2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouseDown);
            this.b2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouseMove);
            this.b2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mouseUp);
            // 
            // r2
            // 
            this.r2.BackColor = System.Drawing.Color.Red;
            this.r2.Location = new System.Drawing.Point(840, 150);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(10, 10);
            this.r2.TabIndex = 5;
            this.r2.TabStop = false;
            this.r2.Tag = "Red Car 2";
            this.toolTip1.SetToolTip(this.r2, "You can change location of car to somewhere else on path by dragging and dropping" +
        " at desired location. \r\nPlease drop exactly on path!!");
            this.r2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouseDown);
            this.r2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouseMove);
            this.r2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mouseUp);
            // 
            // r1
            // 
            this.r1.BackColor = System.Drawing.Color.DarkRed;
            this.r1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.r1.Location = new System.Drawing.Point(840, 340);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(10, 10);
            this.r1.TabIndex = 6;
            this.r1.TabStop = false;
            this.r1.Tag = "Red Car 1";
            this.toolTip1.SetToolTip(this.r1, "You can change location of car to somewhere else on path by dragging and dropping" +
        " at desired location. \r\nPlease drop exactly on path!!");
            this.r1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.mouseDown);
            this.r1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mouseMove);
            this.r1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.mouseUp);
            // 
            // bo
            // 
            this.bo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.bo.Location = new System.Drawing.Point(50, 150);
            this.bo.Name = "bo";
            this.bo.Size = new System.Drawing.Size(300, 200);
            this.bo.TabIndex = 1;
            this.bo.TabStop = false;
            // 
            // bi
            // 
            this.bi.BackColor = System.Drawing.Color.White;
            this.bi.Location = new System.Drawing.Point(60, 160);
            this.bi.Name = "bi";
            this.bi.Size = new System.Drawing.Size(280, 180);
            this.bi.TabIndex = 7;
            this.bi.TabStop = false;
            // 
            // ri
            // 
            this.ri.BackColor = System.Drawing.Color.White;
            this.ri.Location = new System.Drawing.Point(560, 160);
            this.ri.Name = "ri";
            this.ri.Size = new System.Drawing.Size(280, 180);
            this.ri.TabIndex = 8;
            this.ri.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.DarkBlue;
            this.richTextBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBox1.Location = new System.Drawing.Point(12, 387);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(225, 96);
            this.richTextBox1.TabIndex = 9;
            this.richTextBox1.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Blue;
            this.richTextBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBox2.Location = new System.Drawing.Point(254, 387);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(225, 96);
            this.richTextBox2.TabIndex = 10;
            this.richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.BackColor = System.Drawing.Color.DarkRed;
            this.richTextBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBox3.Location = new System.Drawing.Point(503, 387);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.ReadOnly = true;
            this.richTextBox3.Size = new System.Drawing.Size(225, 96);
            this.richTextBox3.TabIndex = 11;
            this.richTextBox3.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.BackColor = System.Drawing.Color.Red;
            this.richTextBox4.ForeColor = System.Drawing.SystemColors.Window;
            this.richTextBox4.Location = new System.Drawing.Point(744, 387);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.ReadOnly = true;
            this.richTextBox4.Size = new System.Drawing.Size(225, 96);
            this.richTextBox4.TabIndex = 12;
            this.richTextBox4.Text = "";
            // 
            // pause
            // 
            this.pause.Location = new System.Drawing.Point(66, 70);
            this.pause.Name = "pause";
            this.pause.Size = new System.Drawing.Size(75, 23);
            this.pause.TabIndex = 13;
            this.pause.Text = "Pause";
            this.pause.UseVisualStyleBackColor = true;
            this.pause.Click += new System.EventHandler(this.pause_Click);
            // 
            // resume
            // 
            this.resume.Location = new System.Drawing.Point(162, 70);
            this.resume.Name = "resume";
            this.resume.Size = new System.Drawing.Size(75, 23);
            this.resume.TabIndex = 14;
            this.resume.Text = "Resume";
            this.resume.UseVisualStyleBackColor = true;
            this.resume.Click += new System.EventHandler(this.resume_Click);
            // 
            // speed
            // 
            this.speed.Location = new System.Drawing.Point(590, 48);
            this.speed.Maximum = 20;
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(195, 45);
            this.speed.TabIndex = 15;
            this.speed.TickFrequency = 2;
            this.speed.Value = 10;
            this.speed.Scroll += new System.EventHandler(this.speed_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 371);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Blue car 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(347, 371);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Blue car 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(574, 371);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Red car 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(814, 371);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Red car 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(654, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Speed Control";
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(66, 22);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 21;
            this.start.Text = "Start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.Tag = "You can drag and drop";
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1017, 557);
            this.Controls.Add(this.start);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.speed);
            this.Controls.Add(this.resume);
            this.Controls.Add(this.pause);
            this.Controls.Add(this.richTextBox4);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.ri);
            this.Controls.Add(this.bi);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.bridge);
            this.Controls.Add(this.bo);
            this.Controls.Add(this.ro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Mutual Exclusion Assignment (15111013)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bridge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.r1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.speed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ro;
        private System.Windows.Forms.PictureBox bridge;
        private System.Windows.Forms.PictureBox b1;
        private System.Windows.Forms.PictureBox b2;
        private System.Windows.Forms.PictureBox r2;
        private System.Windows.Forms.PictureBox r1;
        private System.Windows.Forms.PictureBox bo;
        private System.Windows.Forms.PictureBox bi;
        private System.Windows.Forms.PictureBox ri;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Button pause;
        private System.Windows.Forms.Button resume;
        private System.Windows.Forms.TrackBar speed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

