﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MutualExclusion
{
    public class Message
    {
        public MessageType type;
        public Int64 timestamp;
        public Car senderid;
        public Message(MessageType type,Int64 timestamp,Car senderid)
        {
            this.type = type;
            this.timestamp = timestamp;
            this.senderid = senderid;
        }
    }
}