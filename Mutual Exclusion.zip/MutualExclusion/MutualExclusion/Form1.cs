﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Collections.Generic;

namespace MutualExclusion
{
    public partial class Form1 : Form
    {
        bool isDragged = false;
        Point ptOffset;
        int DELAY = 50;
        delegate void Movecar(PictureBox car);
        delegate void updatetext(RichTextBox richtextbox, Car car);
        delegate void movescar(Car car);
        Thread tb1, tb2, tr1, tr2;
        Car cb1, cb2, cr1, cr2;
        List<Car> RequestSet;
        public Form1()
        {
            InitializeComponent();
            cb1 = new Car(b1);
            cb2 = new Car(b2);
            cr1 = new Car(r1);
            cr2 = new Car(r2);
            tb1 = new Thread(() => Move(cb1));
            tb2 = new Thread(() => Move(cb2));
            tr1 = new Thread(() => Move(cr1));
            tr2 = new Thread(() => Move(cr2));
            RequestSet = new List<Car>();
            RequestSet.Add(cb1);
            RequestSet.Add(cb2);
            RequestSet.Add(cr1);
            RequestSet.Add(cr2);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        public void Move(Car car)
        {

            Point location;
            while (true)
            {
                car.timestamp += car.timeincrement;
                Thread.Sleep(DELAY);
                location = car.car.Location;

                if (Point.Equals(location, new Point(bridge.Location.X - 10, bridge.Location.Y)) ||
                    Point.Equals(location, new Point(bridge.Location.X + 200, bridge.Location.Y)))
                {

                    if (!car.bridgecrossed)
                    {
                        car.getBridge(RequestSet);
                        
                        if (car.lockgained && car.RQ.Peek().car.Equals(car))
                        {
                            
                            if (Point.Equals(location, new Point(bridge.Location.X - 10, bridge.Location.Y)))
                            { car.DirectionOnBridge = Direction.right; update(car); car.bridgecrossed = true; moveright(car.car); }
                            else
                            { car.DirectionOnBridge = Direction.left; update(car); car.bridgecrossed = true; moveleft(car.car); }
                        }
                        else
                        {
                            update(car);
                            if (Point.Equals(location, new Point(bridge.Location.X - 10, bridge.Location.Y)))
                            { moveup(car.car); }
                            else
                            { movedown(car.car); }
                        }
                    }
                    else
                    {
                        car.release(RequestSet);
                        update(car);
                        car.bridgecrossed = false;
                        if (Point.Equals(location, new Point(bridge.Location.X - 10, bridge.Location.Y)))
                        { moveup(car.car); }
                        else { movedown(car.car); }
                    }

                }


                else if (location.Y == bridge.Location.Y && location.X >= bridge.Location.X - 9 && location.X < bridge.Location.X + 200)
                {
                    if (car.DirectionOnBridge == Direction.left) moveleft(car.car);
                    else if (car.DirectionOnBridge == Direction.right) moveright(car.car);

                }
                else if ((location.X == bo.Location.X && location.Y >= bo.Location.Y && location.Y < bo.Location.Y + 190) ||
                    (location.X == ro.Location.X && location.Y < ro.Location.Y + 190 && location.Y >= bridge.Location.Y) ||
                    (location.X == ro.Location.X && location.Y <= bridge.Location.Y))
                { movedown(car.car); }
                else if ((location.X == ro.Location.X + 290 && location.Y > ro.Location.Y && location.Y <= ro.Location.Y + 190) ||
                    (location.X == bo.Location.X + 290 && location.Y < bridge.Location.Y && location.Y > bo.Location.Y) ||
                    (location.X == bo.Location.X + 290 && location.Y > bridge.Location.Y))
                { moveup(car.car); }
                else if (location.Y == ro.Location.Y && ((location.X <= ro.Location.X + 290 && location.X > ro.Location.X) ||
                   (location.X <= bo.Location.X + 290 && location.X > bo.Location.X)))
                { moveleft(car.car); }
                else if (location.Y == ro.Location.Y + 190 && ((location.X >= ro.Location.X && location.X < ro.Location.X + 290) ||
                   (location.X >= bo.Location.X && location.X < bo.Location.X + 290)))
                { moveright(car.car); }


            }
        }

        public void moveleft(PictureBox car)
        {
            if(car.InvokeRequired)
            {
                Movecar d = new Movecar(moveleft);
                this.Invoke(d, new object[] { car });
            }
            else
            car.Location = new Point(car.Location.X - 1, car.Location.Y);
        }

        private void pause_Click(object sender, EventArgs e)
        {
            try
            { tr1.Suspend();
                tr2.Suspend();
                tb2.Suspend();
                tb1.Suspend();
            }
            catch (System.Threading.ThreadStateException ex)
            { }
        }

        
        
        private void resume_Click(object sender, EventArgs e)
        {
            try {
                tr1.Resume();
                tr2.Resume();
                tb2.Resume();
                tb1.Resume();
            }
            catch(System.Threading.ThreadStateException ex)
            { }
        }

        private void speed_Scroll(object sender, EventArgs e)
        {
            DELAY =  (speed.Maximum -speed.Value)<1?1: (speed.Maximum - speed.Value);
        }

        
        private void start_Click(object sender, EventArgs e)
        {
            try {
                tb1.Start();
                tb2.Start();
                tr1.Start();
                tr2.Start();
            }
            catch(ThreadStateException ex)
            { }
        }

        private void mouseDown(object sender, MouseEventArgs e)
        {
            PictureBox car = (PictureBox)sender;
            if (e.Button == MouseButtons.Left)
            {
                isDragged = true;
                Point ptStartPosition = car.PointToScreen(new Point(e.X, e.Y));

                ptOffset = new Point();
                ptOffset.X = car.Location.X - ptStartPosition.X;
                ptOffset.Y = car.Location.Y - ptStartPosition.Y;
            }
            else
            {
                isDragged = false;
            }
        }

        private void mouseMove(object sender, MouseEventArgs e)
        {
            PictureBox car = (PictureBox)sender;
            if (isDragged)
            {
                Point newPoint = car.PointToScreen(new Point(e.X, e.Y));
                newPoint.Offset(ptOffset);
                car.Location = newPoint;
            }
        }

        private void mouseUp(object sender, MouseEventArgs e)
        {
            isDragged = false;
        }

        public void moveright(PictureBox car)
        {
            if (car.InvokeRequired)
            {
                Movecar d = new Movecar(moveright);
                this.Invoke(d, new object[] { car });
            }
            else
                car.Location = new Point(car.Location.X+1, car.Location.Y);
        }
        public void movedown(PictureBox car)
        {
            if (car.InvokeRequired)
            {
                Movecar d = new Movecar(movedown);
                this.Invoke(d, new object[] { car });
            }
            else
                car.Location = new Point(car.Location.X, car.Location.Y + 1);
        }
        public void moveup(PictureBox car)
        {
            if (car.InvokeRequired)
            {
                Movecar d = new Movecar(moveup);
                this.Invoke(d, new object[] { car });
            }
            else
                car.Location = new Point(car.Location.X, car.Location.Y - 1);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }
        public void updatetextbox(RichTextBox richtextbox,Car car)
        {
            if (richtextbox.InvokeRequired)
            {
                updatetext d = new updatetext(updatetextbox);
                this.Invoke(d, new object[] { richtextbox, car });
            }
            else
                richtextbox.Text = "Request Queue's count: " + car.RQ.Count.ToString() + "\n" +
                                    "Brigecrossed: " + car.bridgecrossed.ToString()+"\n"+
                                    (!car.bridgecrossed ? "Got desired replys? " + (car.lockgained?"Yes":"No") + "\n":"") +
                                    "Top of Request Queue: "+ car.RQ.Peek().car.car.Tag.ToString()+"\n"+
                                    "Direction on bridge: " + car.DirectionOnBridge.ToString()+"\n\n"+
                                    richtextbox.Text;
        }

        public void update(Car car)
        {
            if(car.car.Equals(b1))
                updatetextbox(richTextBox1,car);
             else if (car.car.Equals(b2))
                updatetextbox(richTextBox2, car);
             else if (car.car.Equals(r1))
                updatetextbox(richTextBox3, car);
             else
                updatetextbox(richTextBox4, car);
            
        }






    }
}
