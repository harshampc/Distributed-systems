//cc node.c -o node
//chmod +x run.sh
//./run.sh
#define MAXLINE 256
#define NUMBEROFNODES 5
#include<sys/types.h>
#include<sys/socket.h>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include <stdlib.h>
#include <sys/mman.h>



int cinc;
static int nevents;
static int *clk;

void removeChar(char *str, char garbage) {

    char *src, *dst;
    for (src = dst = str; *src != '\0'; src++) {
        *dst = *src;
        if (*dst != garbage) dst++;
    }
    *dst = '\0';
}

int getrandom()
{
	return	rand()%NUMBEROFNODES+1;
}

int getclockincrement()
{
	
        srand(time(NULL));
	return	rand()%10+1;
}

char* readline(int x,char* fname)
{
	int lineNumber = x;

	FILE *file = fopen(fname, "r");
	int count = 1;
	if ( file != NULL )
	{
	    static char line[256]; // suitable maximum line size 
	    while (fgets(line, sizeof line, file) != NULL) // read a line 
	    {
		if (count == lineNumber)
		{
		    fclose(file);
		    return line;
		}
		else
		{
		    count++;
		}
	    }
	    fclose(file);
	}
	else
	{
	    return NULL;
	}
}

int getportnumber(char* line)
{
  char 	*str =line;
  char * pch;
  pch = strtok (str,"\t");
  pch = strtok (NULL, "\t");
  pch = strtok (NULL, "\t");
  return atoi(pch);
}

int gettimestamp(char* line)
{
  char 	*str =line;int i;
  char * pch;
  pch = strtok (str,"\t");
  for(i=0;i<4;i++)
  pch = strtok (NULL, "\t:");

  return atoi(pch);
}

int getsourceid(char* line)
{
 char 	*str =line;int i;
  char * pch;
  pch = strtok (str,"\t");
  for(i=0;i<6;i++)
  pch = strtok (NULL, "\t:");

  return atoi(pch);
}
void peer_receive(char* ofile,int sd, struct sockaddr_in  pcliaddr, socklen_t clilen)
{  
	if ( bind( sd, (struct sockaddr*)&pcliaddr, clilen ) != 0 )
        {}
	int n;
	char mesg[MAXLINE];
	if(recvfrom (sd,mesg,MAXLINE,0,(struct sockaddr*)&pcliaddr,&clilen)<0)
	{printf("error while receiving");}
	else{
	 char mesg2[MAXLINE];
	 strcat(mesg2,mesg);
	 int timestamp=gettimestamp(mesg);
 	 int sourceid = getsourceid(mesg2);
	*clk +=cinc;
	if(*clk<=timestamp)
		*clk=timestamp+1;
	FILE *fptr;
	fptr=fopen(ofile,"a");
	fprintf(fptr,"r %d %d %d\n",sourceid,timestamp,*clk);
	fclose(fptr);
	}
}
void peer_send(char* file,char* ofile,int sourceid, int sd, struct sockaddr_in pservaddr, socklen_t servlen)
{
	FILE *fptr;
	int	n, receiverid;
	char	sendline[MAXLINE];
	I: 
	receiverid=getrandom();
	if(receiverid==sourceid)goto I;
	char* line=readline(receiverid,file);
	
	char ts[20];*clk += cinc;// send event
	sprintf(ts,"\ttimestamp:%d\tsource:%d",*clk,sourceid);
	strcat(line,ts);
	removeChar(line,'\n');
	char nline[50];strcat(nline,line);
	pservaddr.sin_port=htons(getportnumber(nline));
		
	if(sendto(sd, line, strlen(line), 0, (struct sockaddr*)&pservaddr, servlen)<0)
	{}
	
	fptr=fopen(ofile,"a");
	fprintf(fptr,"s %d %d\n",receiverid,*clk);
	fclose(fptr);
	
}

int main(int argc,char* argv[])
{ 
  clk = mmap(NULL, sizeof *clk, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  int lineno = atoi(argv[2]);
  char ofile[]="output";
  strcat(ofile,argv[2]);
  pid_t cpid;
  char* line=readline(lineno,argv[1]);
  if(line== NULL) exit(0);

 int rport=getportnumber(line);

  cinc  = getclockincrement();
 // printf("clock increment : %d\n",cinc);



	int sd;
	char buff[1024];
	struct sockaddr_in servaddr;
	socklen_t len;
	len=sizeof(servaddr);
	//UDP socket is created, an Internet socket address structure is filled with wildcard address & server’s well known port
	sd = socket(AF_INET,SOCK_DGRAM,0);
	if(sd<0)
	{
	perror("Cannot open socket");
	exit(1);
	}
	bzero(&servaddr,len);
	//Socket address structure
	servaddr.sin_family=AF_INET;
	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	servaddr.sin_port=htons(rport);

	sleep(10);
 cpid =fork();

if(cpid==0)
	{
		while(nevents<50){
		nevents += 1;
		if(rand()%2==1)
			{
			 *clk += cinc;// local event
			 FILE *fptr;
		   	 fptr=fopen(ofile,"a");
		         fprintf(fptr,"l %d\n",*clk);
		   	 fclose(fptr);
			}
		else		
		{peer_send(argv[1],ofile,lineno,sd, servaddr, sizeof(servaddr));
		 sleep(1);}
		}
	}
	else
	{
		while(1){
		peer_receive(ofile,sd, servaddr, sizeof(servaddr) );
		sleep(1);
		} 
	}


close(sd);

return 0;
}









