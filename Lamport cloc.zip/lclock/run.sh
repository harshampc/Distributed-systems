./node config 1 &
./node config 2 &
./node config 3 &
./node config 4 &
./node config 5
