
/* A simple server in the internet domain using TCP
The port number is passed as an argument */
 #include <stdio.h>
#include <sys/types.h>
 #include <sys/socket.h>
 #include <netinet/in.h>



void do_processing (int sock) {

int n;

char buffer[256];
int size;
n = read(sock,&size,sizeof(int));
if (n < 0)
error("ERROR reading from socket");
printf("Client  is registered. Here is the size of array: %d\n",size);
n = write(sock,"I got size of array.",20);
if (n < 0)
error("ERROR writing to socket");

int array[size];

n = read(sock,array,sizeof(array));
if (n < 0)
error("ERROR reading from socket");

printf("Array is read.");
n = write(sock,"I got array",18);
if (n < 0)
error("ERROR writing to socket");
n = read(sock,buffer,255);

int c,d,swap;
for (c = 0 ; c < ( size - 1 ); c++)
  {
    for (d = 0 ; d < size - c - 1; d++)
    {
      if (array[d] > array[d+1]) /* For decreasing order use < */
      {
        swap       = array[d];
        array[d]   = array[d+1];
        array[d+1] = swap;
      }
    }
  }

int s = write(sock,array,sizeof(array));
if (s < 0)
error("ERROR while sending sorted array.");
else
printf("Sent sorted array");
}




void error(char *msg) {
perror(msg);
exit(1);
}




int main(int argc, char *argv[]) {

int sockfd, newsockfd, portno, clilen;

char buffer[256];

struct sockaddr_in serv_addr, cli_addr;

int n;
int m;pid_t pid;
if (argc < 2) {
fprintf(stderr,"ERROR, no port provided\n");
exit(1);
}

sockfd = socket(AF_INET, SOCK_STREAM, 0);

if (sockfd < 0)
error("ERROR opening socket");

bzero((char *) &serv_addr, sizeof(serv_addr));

portno = atoi(argv[1]);

serv_addr.sin_family = AF_INET;

serv_addr.sin_addr.s_addr = INADDR_ANY;

serv_addr.sin_port = htons(portno);

if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
error("ERROR on binding");

listen(sockfd,5);


clilen = sizeof(cli_addr);


while (1) {

newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
if (newsockfd < 0)
error("ERROR on accept");
/* Fork and create a child process */
pid = fork();
if (pid < 0)
error("ERROR on fork");

if (pid == 0)do_processing(newsockfd);
else close(newsockfd);
}
return 0;

}











